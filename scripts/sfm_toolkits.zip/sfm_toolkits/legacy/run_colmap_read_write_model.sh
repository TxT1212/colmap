python3 colmap_read_write_model.py  \
--input_model /media/netease/Software/Dataset/LandmarkAR/DistrictC/C11/sparse/geo \
--input_format .bin \
--output_model /media/netease/Software/Dataset/LandmarkAR/DistrictC/C11/sparse/geo_txt \
--output_format .txt \
