python3 iblmall_export_gt_to_colmap.py  \
--path /media/netease/Software/Dataset/Oasis/ibl_mall/ibl_dataset_cvpr17_3852/training_gt/ \
--output_image /media/netease/Software/Dataset/Oasis/ibl_mall/ibl_dataset_cvpr17_3852/evo_eval/gt/images.txt \
--output_camera /media/netease/Software/Dataset/Oasis/ibl_mall/ibl_dataset_cvpr17_3852/evo_eval/gt/cameras.txt \
--is_crop_resize True \
--src_size_w 2992 \
--src_size_h 2000 \
--crop_size_w 2992 \
--crop_size_h 1683 \
--resize_scale 1.0

