python3 run_part_model.py \
--colmap_folder /media/administrator/dataset/oasis/C6/PartMapModels/BaseModels/C6_part_F1Hall_Sand \
--input_model sparse/full_aligned_scaled \
--match_file match_image_list.txt \
--output_model sparse/base 