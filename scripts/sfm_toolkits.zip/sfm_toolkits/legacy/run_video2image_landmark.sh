python3 export_image_from_video_all.py \
	--dataset_path /media/administrator/dataset/oasis/HZZoo/RawData/cloudy_0522  \
        --interval 10  \
	--clip -1  \
	--multithread  \
       	 --resize  \
     	 --width 1280   \
     	 --height 720 


# python3 export_image_from_video.py \
# 	--dataset_path /media/administrator/dataset/oasis/LandmarkAR/C11_mobile_subtests/v_zhangyan  \
#         --interval 1  \
#         --clip -1 \
#        	--resize  \
#      	--width 640   \
#      	--height 360
