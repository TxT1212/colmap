python run_scale_ezxr.py \
/media/netease/Storage/LargeScene/Scene/XixiWetland/colmap_model/xraw_test_material \
/media/netease/Storage/LargeScene/Scene/XixiWetland/colmap_model/xraw_test_material/sparse/gravity