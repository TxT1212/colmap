
# geos.txt -> evo txt
#python colmap_to_tum_evo.py --src_path /home/fjt/Code/HF-Net/benchmark/ibl_dataset_cvpr17_3852/sparse/aslfeat/0/geos.txt --tgt_path /home/fjt/Code/HF-Net/benchmark/ibl_dataset_cvpr17_3852/evo_eval/gt/geos.txt --src_output_path /home/fjt/Code/HF-Net/benchmark/ibl_dataset_cvpr17_3852/evo_eval/aslfeat_gt/src.txt --tgt_output_path /home/fjt/Code/HF-Net/benchmark/ibl_dataset_cvpr17_3852/evo_eval/aslfeat_gt/tgt.txt

# colmap model -> evo txt
python colmap_to_tum_evo.py --src_path /home/fjt/Code/HF-Net/benchmark/ibl_dataset_cvpr17_3852/sparse/aslfeat/0/ --tgt_path /home/fjt/Code/HF-Net/benchmark/ibl_dataset_cvpr17_3852/evo_eval/gt/geos.txt --src_output_path /home/fjt/Code/HF-Net/benchmark/ibl_dataset_cvpr17_3852/evo_eval/aslfeat/0/src.txt --tgt_output_path /home/fjt/Code/HF-Net/benchmark/ibl_dataset_cvpr17_3852/evo_eval/aslfeat/0/tgt.txt
